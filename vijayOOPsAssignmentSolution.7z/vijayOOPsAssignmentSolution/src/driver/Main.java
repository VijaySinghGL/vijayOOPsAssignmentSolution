package driver;

import Admin.AdminDepartment;
import Hr.HrDepartment;
import Tech.TechDepartment;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		AdminDepartment Admin = new AdminDepartment();
		TechDepartment Tech = new TechDepartment();
		HrDepartment Hr = new HrDepartment();
		
		System.out.println(Admin.departmentName());
		System.out.println(Admin.getTodaysWork());
		System.out.println(Admin.getWorkDeadline());
		System.out.println(Admin.isTodayAHoliday());
		
		System.out.println();
		System.out.println(Hr.departmentName());
		System.out.println(Hr.doActivity());
		System.out.println(Hr.getTodaysWork());
		System.out.println(Hr.getWorkDeadline());
		System.out.println(Hr.isTodayAHoliday());
		
		System.out.println();
		System.out.println(Tech.departmentName());
		System.out.println(Tech.getTodaysWork());
		System.out.println(Tech.getWorkDeadline());
		System.out.println(Tech.getTechStackInformation());
		System.out.println(Tech.isTodayAHoliday());
		
	}

}
