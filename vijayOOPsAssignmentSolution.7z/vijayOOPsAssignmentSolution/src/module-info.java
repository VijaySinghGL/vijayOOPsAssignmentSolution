module vijayOOPsAssignmentSolution {
}